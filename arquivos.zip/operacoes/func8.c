#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "func8.h"
#include "../arquivos/arquivos.h"
#include "../cabecalho/cabecalho.h"
#include "../registro/registro.h"
#include "../utilitarios/utils.h"
#include "../arvoreB/arvoreB.h"
#include "../cabecalhoArvoreB/cabecalhoArvoreB.h"


static int buscarSequencialFunc8(FILE *bin, CampoBusca criterios[], int qtdCriterios)
{
    Registro r;
    int status_leitura;
    int encontrados = 0;

    fseek(bin, TAM_CABECALHO, SEEK_SET);

    while ((status_leitura = leRegistroBin(bin, &r)) != 0)
    {
        if (status_leitura == 2)
        {
            continue;
        }

        if (registroSatisfazCriterios(&r, criterios, qtdCriterios))
        {
            imprimeRegistro(&r);
            encontrados = 1;
        }
    }

    return encontrados;
}

static int buscarComIndiceFunc8(FILE *bin, FILE *indice, CampoBusca criterios[], int qtdCriterios, int valorCodEstacao){
    int referencia;
    Registro r;
    int status_leitura;

    if (!buscarArvoreB(indice, valorCodEstacao, &referencia)){
        return 0;
    }

    fseek(bin, referencia, SEEK_SET);
    status_leitura = leRegistroBin(bin, &r);

    if (status_leitura != 1){
        return 0;
    }

    if (!registroSatisfazCriterios(&r, criterios, qtdCriterios)){
        return 0;
    }

    imprimeRegistro(&r);
    return 1;
}

void func8(char *arqEntrada, char *arqIndice, int n){
    FILE *bin = abrirArquivo(arqEntrada, "rb");
    if (!bin){
        printf("Falha no processamento do arquivo.\n");
        return;
    }

    FILE *indice = abrirArquivo(arqIndice, "rb");
    if (!indice){
        printf("Falha no processamento do arquivo.\n");
        fecharArquivo(bin);
        return;
    }

    Cabecalho c;
    if (!leCabecalho(bin, &c)){
        printf("Falha no processamento do arquivo.\n");
        fecharArquivo(bin);
        fecharArquivo(indice);
        return;
    }

    CabecalhoArvoreB cabecalhoIndice;
    if (!lerCabecalhoArvoreB(indice, &cabecalhoIndice) || cabecalhoIndice.status != '1'){
        printf("Falha no processamento do arquivo.\n");
        fecharArquivo(bin);
        fecharArquivo(indice);
        return;
    }

    for (int i = 0; i < n; i++){
        int m;
        scanf("%d", &m);

        CampoBusca criterios[m];
        int possuiCodEstacao;
        int valorCodEstacao;
        int encontrados;

        lerCriteriosBusca(criterios, m, &possuiCodEstacao, &valorCodEstacao);

        if (possuiCodEstacao){
            encontrados = buscarComIndiceFunc8(bin, indice, criterios, m, valorCodEstacao);
        }
        else{
            encontrados = buscarSequencialFunc8(bin, criterios, m);
        }

        if (!encontrados){
            printf("Registro inexistente.\n");
        }
        printf("\n");
    }

    fecharArquivo(bin);
    fecharArquivo(indice);
}
